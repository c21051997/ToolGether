from django.apps import AppConfig


class WebLoginConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Web_Login'
