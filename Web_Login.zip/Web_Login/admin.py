from django.contrib import admin
from Web_Login.models import User, Profile

# Register your models here.

admin.site.register(User)
admin.site.register(Profile)