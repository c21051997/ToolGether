from django.contrib import admin
from Web_Main.models import category, slider, Item

# Register your models here.

admin.site.register(category)
admin.site.register(slider)
admin.site.register(Item)