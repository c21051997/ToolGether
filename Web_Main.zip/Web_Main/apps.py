from django.apps import AppConfig


class WebMainConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Web_Main'
